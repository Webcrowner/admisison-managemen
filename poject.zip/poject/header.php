<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db.php';
?>

<link rel="stylesheet" href="style.css">

<header>
    <div class="logo">
        <img src="jap.jpeg" alt="Admin Logo">
    </div>
    <h1>Admin Panel</h1>
    <nav>
        <button onclick="location.href='index.php'">
            <i class="fas fa-list"></i> Applications
        </button>
        <button onclick="location.href='apply.php'">
            <i class="fas fa-paper-plane"></i> Submit Application
        </button>
    </nav>
    <div class="menu-icon" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </div>
</header>

