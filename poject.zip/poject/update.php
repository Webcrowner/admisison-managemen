<?php
include 'header.php';
include 'db.php'; // Ensure the database connection is included

// Load PHPMailer
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM applications WHERE id = $id";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $status = $_POST['status'];
    $message = $_POST['message'];
    $email = $row['email']; // Get applicant's email from database
    $name = $row['name'];   // Get applicant's name

    // Update status in the database
    $updateQuery = "UPDATE applications SET status='$status', message='$message' WHERE id=$id";
    if ($conn->query($updateQuery) === TRUE) {
        echo "<p>Application updated successfully!</p>";

        // Send Email Notification
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Your SMTP server (Gmail, Outlook, etc.)
            $mail->SMTPAuth = true;
            $mail->Username = 'jesuspeace514@gmail.com'; // Your email
            $mail->Password = 'powerofgod'; // Your email password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Email settings
            $mail->setFrom('your-email@gmail.com', 'Admin');
            $mail->addAddress($email, $name); // Send email to applicant
            $mail->Subject = "Application Status Update";
            $mail->Body = "Dear $name,\n\nYour application status has been updated to: $status.\n\nMessage: $message\n\nBest regards,\nAdmissions Office";

            $mail->send();
            echo "<p>Email notification sent to applicant!</p>";
        } catch (Exception $e) {
            echo "<p>Email could not be sent. Mailer Error: {$mail->ErrorInfo}</p>";
        }
    } else {
        echo "<p>Error updating application: " . $conn->error . "</p>";
    }
}
?>


<h2>User Status Update</h2>
<form method="POST">
    <!-- Centered Image -->
    <div class="form-image">
        <img src="" alt="Status Update">
    </div>

    <!-- Status Dropdown -->
    <label for="status">Select Status:</label>
    <select name="status" id="status">
        <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>🟡 Pending</option>
        <option value="Accepted" <?php if ($row['status'] == 'Accepted') echo 'selected'; ?>>✅ Accepted</option>
        <option value="Rejected" <?php if ($row['status'] == 'Rejected') echo 'selected'; ?>>❌ Rejected</option>
    </select>

    <!-- Custom Message -->
    <label for="message">Custom Message:</label>
    <textarea name="message" id="message" placeholder="Enter your message here..."><?php echo $row['message']; ?></textarea>

    <!-- Submit Button -->
    <button type="submit">Update Status</button>
</form>



