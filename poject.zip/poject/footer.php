<footer>
    <p>&copy; <?php echo date("Y"); ?> Statues. All rights reserved.</p>
</footer>
</body>
</html>
